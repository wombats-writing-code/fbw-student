// prod credentials

let credentials = {
  role: 'student',
  appID: 'phRx3C1kz9n8Ee8C-lq3kA',
  appKey: '2NkxWkDknhaA27PispVCiA',
  host: process.env.NODE_ENV === 'production' ? 'https://acc.desire2learn.com' : 'http://localhost:8888/mock-d2l',
  port: process.env.NODE_ENV === 'production' ? 443 : 80,     // so that the valence lib doesn't append a :port to the string.
  callbackUrl: process.env.NODE_ENV === 'production' ? 'https://fbw-student.mit.edu/d2l-callback' : 'http://localhost:3000'
}

module.exports = credentials;
